package com.example.battzionni.class2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Color;
import android.util.Log;
import java.util.Random;

public class MainActivity extends AppCompatActivity
{

    private final String TAG = getClass().getSimpleName();
    private Button counter;
    private Button b_color;
    private TextView presses;
    int count_presses;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        counter = (Button)findViewById(R.id.counter);
        b_color = (Button)findViewById(R.id.change_color);
        presses = (TextView)findViewById(R.id.presses);
        count_presses = 0;

        counter.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                if (v.getId() == counter.getId())
                {
                    Log.i(TAG, "Button was pressed!");
                    count_presses++;
                    presses.setText(count_presses + " " + getResources().getString(R.string.presses_text));
                }
            }

        });

        b_color.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (v.getId() == b_color.getId()) {
                    Log.i(TAG, "Button was pressed!");
                    Random rnd = new Random();
                    int color_rnd = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                    counter.setBackgroundColor(color_rnd);
                    color_rnd = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                    presses.setBackgroundColor(color_rnd);
                    color_rnd = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
                    b_color.setBackgroundColor(color_rnd);

                }
            }

        });

        counter.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                if (v.getId() == counter.getId()) {
                    count_presses = 0;
                    presses.setText("0 " + getResources().getString(R.string.presses_text));
                }
                return true;
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
