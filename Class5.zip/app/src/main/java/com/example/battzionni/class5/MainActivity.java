package com.example.battzionni.class5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private final String TAG = getClass().getSimpleName();
    private TextView allTimes;
    private EntryTimeDAL Dal;
    private String time;
    private ArrayList<String> allTimesList;
    private String allTimesString;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Dal = new EntryTimeDAL(this);

        time = DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime());
        Dal.addTimeEntry(time);

        allTimesList = Dal.getAllTimeEntriesList();
        allTimesString = allTimesList.toString();

        allTimes = (TextView)findViewById(R.id.times_list);
        allTimes.setText(allTimesString);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
