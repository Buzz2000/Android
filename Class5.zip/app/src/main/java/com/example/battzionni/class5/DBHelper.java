package com.example.battzionni.class5;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by battzionni on 13/04/2016.
 */
public class DBHelper extends SQLiteOpenHelper
{
    public final static int DATABASE_VERSION = 1;
    private final static String DATABASE_NAME = "entryTimesDataBase.db";
    private final String TAG = getClass().getSimpleName();

    public DBHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION)   ;
    }

    public void onCreate(SQLiteDatabase db)
    {
        String CREATE_TABLE = "CREATE TABLE "+EntryTimeContract.TABLE_NAME+"("+EntryTimeContract.ENTRY_TIME+" TEXT PRIMARY KEY);";
        db.execSQL(CREATE_TABLE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data...");
        db.execSQL("DROP TABLE IF EXISTS " + EntryTimeContract.TABLE_NAME);
        onCreate(db);
    }

}
