package com.example.battzionni.class5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by battzionni on 13/04/2016.
 */
public class EntryTimeDAL {

    private DBHelper helper;
    private SQLiteDatabase db;

    private final static long ERROR = -1l;
    private final String TAG = getClass().getSimpleName();

    public EntryTimeDAL(Context context)
    {
        helper = new DBHelper(context);
    }

    //Add new entry time to data base
    public void addTimeEntry(String time)
    {
        SQLiteDatabase db = helper.getWritableDatabase();

        ContentValues val = new ContentValues();
        val.put(EntryTimeContract.ENTRY_TIME, time);

        long row = db.insert(EntryTimeContract.TABLE_NAME, null, val);
        if(row == ERROR)
        {
            Log.e(TAG, "Error in insertion new time to the table...");
        }
        else
        {
            Log.d(TAG, "New time inserted into row "+row);
        }
    }

    //Get all entry times from data base and return it as a cursor
    public Cursor getAllTimeEntriesCursor()
    {
        String allTimesQuery = "SELECT * FROM " + EntryTimeContract.TABLE_NAME;
        db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(allTimesQuery, null);
        db.close();
        c.close();
        return c;
    }

    public ArrayList getAllTimeEntriesList()
    {
        Log.d(TAG, "In getAllList!");
        ArrayList<String> timesList = new ArrayList<String>();
        String allTimesQuery = "SELECT * FROM " + EntryTimeContract.TABLE_NAME;
        db = helper.getWritableDatabase();
        Cursor c = db.rawQuery(allTimesQuery, null);

        if(c.moveToFirst())
        {
            do
            {
                timesList.add(c.getString(0));
            }while (c.moveToNext());
        }

        db.close();
        c.close();
        return timesList;
    }

}
