package com.example.battzionni.class5;

import android.provider.BaseColumns;

/**
 * Created by battzionni on 13/04/2016.
 */
public class EntryTimeContract implements BaseColumns{

    public static final String TABLE_NAME  = "entry_times";

    //Column
    public static final String ENTRY_TIME = "entry_time";
}
